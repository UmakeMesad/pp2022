import math
import domains
import input
import math
def getName(self):
        return self.name    

def getName(self):
        return self.nameofcourse

def list_mark(mark):
    mark.list()

def sorybyaverageofmark(listStudent,mark):
    return listStudent.sortbyaverageofmark(mark)